import React, { useEffect, useState } from 'react'

const API_BASE = import.meta.env.VITE_API_BASE || 'http://localhost:8000'

function UploadCard({ onUploaded }) {
  const [file, setFile] = useState(null)
  const [busy, setBusy] = useState(false)
  const upload = async () => {
    if (!file) return
    setBusy(true)
    const fd = new FormData()
    fd.append('file', file)
    try {
      const r = await fetch(`${API_BASE}/upload-resume`, { method: 'POST', body: fd })
      if (!r.ok) throw new Error(await r.text())
      const data = await r.json()
      onUploaded(data)
    } catch (e) {
      alert('Upload failed: ' + e)
    } finally {
      setBusy(false)
    }
  }
  return (
    <div className="card space-y-4">
      <h2 className="text-xl font-semibold">Upload PDF</h2>
      <input type="file" accept="application/pdf" onChange={e => setFile(e.target.files[0])} />
      <button className="btn btn-primary" onClick={upload} disabled={busy || !file}>
        {busy ? 'Processing…' : 'Upload & Analyze'}
      </button>
    </div>
  )
}

function HistoryList({ selectedId, onSelect }) {
  const [items, setItems] = useState([])
  const [loading, setLoading] = useState(true)
  const refresh = async () => {
    setLoading(true)
    const r = await fetch(`${API_BASE}/insights`)
    const data = await r.json()
    setItems(data)
    setLoading(false)
  }
  useEffect(() => { refresh() }, [])
  return (
    <div className="card">
      <div className="flex items-center justify-between mb-3">
        <h3 className="text-lg font-medium">History</h3>
        <button className="btn btn-ghost" onClick={refresh}>Refresh</button>
      </div>
      {loading ? <p>Loading…</p> : (
        <ul className="space-y-2">
          {items.map(it => (
            <li key={it.id}>
              <button
                onClick={() => onSelect(it.id)}
                className={`w-full text-left p-3 rounded-xl hover:bg-neutral-100 dark:hover:bg-neutral-700 ${selectedId === it.id ? 'ring-2 ring-indigo-400' : ''}`}
              >
                <div className="flex items-center justify-between">
                  <span className="font-medium">{it.filename}</span>
                  <span className="badge">{new Date(it.created_at).toLocaleString()}</span>
                </div>
                <div className="text-xs mt-1 opacity-70">Method: {it.method}</div>
              </button>
            </li>
          ))}
        </ul>
      )}
    </div>
  )
}

function InsightView({ id }) {
  const [data, setData] = useState(null)
  useEffect(() => {
    if (!id) return
    ;(async () => {
      const r = await fetch(`${API_BASE}/insights?id=${id}`)
      const arr = await r.json()
      setData(arr[0])
    })()
  }, [id])
  if (!id) return <div className="card"><p>Select an item from history to view insights.</p></div>
  if (!data) return <div className="card"><p>Loading…</p></div>
  return (
    <div className="card space-y-3">
      <div className="flex items-center gap-3">
        <h3 className="text-lg font-semibold">{data.filename}</h3>
        <span className="badge">{data.method === 'ai' ? 'AI Summary' : 'Fallback'}</span>
      </div>
      <textarea readOnly value={data.summary} />
    </div>
  )
}

export default function App() {
  const [selectedId, setSelectedId] = useState(null)
  const [lastUpload, setLastUpload] = useState(null)

  const handleUploaded = (data) => {
    setSelectedId(data.id)
    setLastUpload(data)
  }

  return (
    <div className="container space-y-6">
      <header className="flex items-center justify-between">
        <h1 className="text-2xl font-bold">AI-Powered Document Insight Tool</h1>
        <a className="text-sm underline" href="https://docs.sarvam.ai/api-reference-docs/introduction" target="_blank">Sarvam API Docs</a>
      </header>
      <UploadCard onUploaded={handleUploaded} />
      <div className="grid md:grid-cols-2 gap-6">
        <HistoryList selectedId={selectedId} onSelect={setSelectedId} />
        <InsightView id={selectedId} />
      </div>
      {lastUpload && (
        <div className="text-xs opacity-70">
          <p>Last processed: <code>{lastUpload.id}</code> ({lastUpload.method})</p>
        </div>
      )}
      <footer className="text-xs opacity-60 pt-8">© {new Date().getFullYear()} Document Insight Tool</footer>
    </div>
  )
}
