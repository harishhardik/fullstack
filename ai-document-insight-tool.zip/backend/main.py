\
import os
import uuid
import re
from datetime import datetime
from typing import Optional, List

import httpx
from fastapi import FastAPI, UploadFile, File, HTTPException, Query
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
from sqlalchemy import create_engine, Column, String, DateTime, Text
from sqlalchemy.orm import declarative_base, sessionmaker
from pdfminer.high_level import extract_text
from dotenv import load_dotenv

load_dotenv()

SARVAM_API_KEY = os.getenv("SARVAM_API_KEY", "")
SARVAM_BASE_URL = os.getenv("SARVAM_BASE_URL", "https://api.sarvam.ai")
MODEL_NAME = os.getenv("SARVAM_MODEL", "sarvam-m")

UPLOAD_DIR = os.path.join(os.path.dirname(__file__), "uploads")
os.makedirs(UPLOAD_DIR, exist_ok=True)

DATABASE_URL = os.getenv("DATABASE_URL", f"sqlite:///{os.path.join(os.path.dirname(__file__), 'insights.db')}")

engine = create_engine(DATABASE_URL, future=True)
SessionLocal = sessionmaker(bind=engine, autoflush=False, autocommit=False)
Base = declarative_base()

class Insight(Base):
    __tablename__ = "insights"
    id = Column(String, primary_key=True, index=True)
    filename = Column(String, nullable=False)
    created_at = Column(DateTime, default=datetime.utcnow, nullable=False)
    summary = Column(Text, nullable=False)
    method = Column(String, nullable=False)  # "ai" or "fallback"
    word_count = Column(String, nullable=True)  # JSON string of top words in fallback
    text_hash = Column(String, nullable=True)

Base.metadata.create_all(bind=engine)

app = FastAPI(title="AI-Powered Document Insight Tool", version="1.0.0")

# CORS for local dev (Vite default port 5173, or Next 3000)
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

class UploadResponse(BaseModel):
    id: str
    filename: str
    created_at: str
    summary: str
    method: str

class InsightItem(BaseModel):
    id: str
    filename: str
    created_at: str
    summary: str
    method: str

def clean_text_for_freq(text: str) -> str:
    # Normalize whitespace and lowercase
    return re.sub(r"\s+", " ", text).lower()

STOPWORDS = set("""a an the and or but if while for to in on with of from by at this that these those is are was were be been being as it its it's he she they them we you your i me my our ours their theirs his her hers not no yes do does did done can could should would may might will just than then so such via """.split())

def top_n_words(text: str, n: int = 5):
    cleaned = re.sub(r"[^a-zA-Z]", " ", text).lower()
    tokens = [t for t in cleaned.split() if t and t not in STOPWORDS and len(t) > 2]
    freq = {}
    for t in tokens:
        freq[t] = freq.get(t, 0) + 1
    top = sorted(freq.items(), key=lambda kv: kv[1], reverse=True)[:n]
    return top

async def summarize_with_sarvam(content: str) -> str:
    if not SARVAM_API_KEY:
        raise RuntimeError("Missing SARVAM_API_KEY")
    url = f"{SARVAM_BASE_URL.rstrip('/')}/chat/completions"
    headers = {"api-subscription-key": SARVAM_API_KEY}
    payload = {
        "model": MODEL_NAME,
        "messages": [
            {"role": "system", "content": "You are a helpful assistant that summarizes resumes and documents into crisp, bullet-style insights."},
            {"role": "user", "content": f"Summarize this resume into key bullet points (skills, experience, education, notable achievements, and a one-line profile). Keep it under 120 words.\n\nDocument:\n{content}"}
        ],
        "temperature": 0.3,
        "max_tokens": 300
    }
    async with httpx.AsyncClient(timeout=30) as client:
        r = await client.post(url, headers=headers, json=payload)
        r.raise_for_status()
        data = r.json()
        # Sarvam API is OpenAI-like; responses generally at choices[0].message.content
        try:
            return data["choices"][0]["message"]["content"].strip()
        except Exception:
            # Fallback if structure differs
            return str(data)

@app.post("/upload-resume", response_model=UploadResponse)
async def upload_resume(file: UploadFile = File(...)):
    if not file.filename.lower().endswith(".pdf"):
        raise HTTPException(status_code=400, detail="Only PDF files are supported.")
    # Save file
    uid = str(uuid.uuid4())
    safe_name = f"{uid}_{file.filename.replace(' ', '_')}"
    save_path = os.path.join(UPLOAD_DIR, safe_name)
    with open(save_path, "wb") as f:
        content = await file.read()
        f.write(content)
    # Extract text
    try:
        text = extract_text(save_path) or ""
    except Exception as e:
        raise HTTPException(status_code=400, detail=f"Failed to read PDF: {e}")
    if not text.strip():
        raise HTTPException(status_code=400, detail="No extractable text found in the PDF.")
    # Try Sarvam AI summarize
    method = "ai"
    try:
        summary = await summarize_with_sarvam(text)
    except Exception as e:
        # Fallback
        method = "fallback"
        pairs = top_n_words(text, 5)
        summary = "Sarvam AI unavailable. Top 5 frequent words:\n" + "\n".join(f"- {w} ({c})" for w, c in pairs)
        wc_json = str(dict(pairs))
    else:
        wc_json = None

    # Persist
    db = SessionLocal()
    try:
        item = Insight(
            id=uid,
            filename=file.filename,
            created_at=datetime.utcnow(),
            summary=summary,
            method=method,
            word_count=wc_json,
            text_hash=str(hash(text[:10000])),
        )
        db.add(item)
        db.commit()
    finally:
        db.close()

    return UploadResponse(
        id=uid, filename=file.filename, created_at=datetime.utcnow().isoformat(), summary=summary, method=method
    )

@app.get("/insights", response_model=List[InsightItem])
def list_insights(id: Optional[str] = Query(default=None, description="If provided, returns only this insight id")):
    db = SessionLocal()
    try:
        q = db.query(Insight).order_by(Insight.created_at.desc())
        if id:
            q = q.filter(Insight.id == id)
        rows = q.all()
        return [
            InsightItem(
                id=row.id,
                filename=row.filename,
                created_at=row.created_at.isoformat(),
                summary=row.summary,
                method=row.method,
            )
            for row in rows
        ]
    finally:
        db.close()
